import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json({ limit: "64kb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const PORT = process.env.PORT || 3000;

app.get("/health", (_req, res) => res.json({ ok: true, app: "Rocky Dot" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions:
        "You are Rocky Dot, a friendly personal AI assistant for Rocky Bhai. " +
        "Be concise, helpful, safe, and natural. Reply in the user's language, " +
        "often Hinglish/Hindi when appropriate.",
      input: message
    });

    res.json({ reply: response.output_text || "I couldn't generate a reply." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "AI request failed" });
  }
});

app.listen(PORT, () => console.log(`Rocky Dot backend listening on ${PORT}`));