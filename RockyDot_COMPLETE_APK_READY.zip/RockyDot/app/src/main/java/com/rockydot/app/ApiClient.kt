package com.rockydot.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    // Replace this with YOUR secure backend URL after deployment.
    // Do NOT put an OpenAI API key in the Android app.
    private const val BACKEND_URL = "https://YOUR-BACKEND.example.com/chat"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun ask(message: String): String {
        return try {
            val body = JSONObject().put("message", message).toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(BACKEND_URL)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return "Backend error ${response.code}. Check your server URL."
                val raw = response.body?.string() ?: return "No response."
                JSONObject(raw).optString("reply", "No reply received.")
            }
        } catch (e: Exception) {
            "Rocky Dot backend connect nahi ho paya. Backend URL check karo."
        }
    }
}