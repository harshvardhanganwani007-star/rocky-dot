package com.rockydot.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
            }
        }

        setContent {
            RockyDotApp(
                speak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rocky-dot") },
                startListening = { onText ->
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) return@RockyDotApp

                    recognizer?.destroy()
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                        override fun onResults(results: Bundle?) {
                            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                ?.firstOrNull()
                            if (!text.isNullOrBlank()) onText(text)
                        }
                        override fun onError(error: Int) {}
                        override fun onReadyForSpeech(p: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(r: Float) {}
                        override fun onBufferReceived(b: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onPartialResults(b: Bundle?) {}
                        override fun onEvent(t: Int, p: Bundle?) {}
                    })
                    recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    })
                },
                requestMic = {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
                }
            )
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun RockyDotApp(
    speak: (String) -> Unit,
    startListening: ((String) -> Unit) -> Unit,
    requestMic: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatMessage("assistant", "Hi Rocky Bhai 👋 Main Rocky Dot hoon. Bol, kya karna hai?")) }
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8B5CF6),
            background = Color(0xFF09090B),
            surface = Color(0xFF141417)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF09090B)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(46.dp).background(Color(0xFF8B5CF6), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("D", fontWeight = FontWeight.Bold, fontSize = 22.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Rocky Dot", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(if (busy) "Thinking…" else "Online", color = Color.LightGray, fontSize = 13.sp)
                    }
                }

                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(messages) { msg ->
                        val isUser = msg.role == "user"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                            Surface(
                                color = if (isUser) Color(0xFF25212F) else Color(0xFF17171B),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Text(msg.text, Modifier.padding(14.dp), fontSize = 16.sp)
                            }
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message Rocky Dot…") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(
                                    androidx.compose.ui.platform.LocalContext.current,
                                    Manifest.permission.RECORD_AUDIO
                                ) != PackageManager.PERMISSION_GRANTED
                            ) requestMic()
                            else startListening { spoken -> input = spoken }
                        },
                        modifier = Modifier.size(54.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = CircleShape
                    ) { Text("🎙") }
                    Spacer(Modifier.width(6.dp))
                    Button(
                        enabled = input.isNotBlank() && !busy,
                        onClick = {
                            val q = input.trim()
                            input = ""
                            messages.add(ChatMessage("user", q))
                            busy = true
                            scope.launch(Dispatchers.IO) {
                                val answer = ApiClient.ask(q)
                                launch(Dispatchers.Main) {
                                    busy = false
                                    messages.add(ChatMessage("assistant", answer))
                                    speak(answer)
                                }
                            }
                        },
                        modifier = Modifier.size(54.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = CircleShape
                    ) { Text("➤") }
                }
            }
        }
    }
}