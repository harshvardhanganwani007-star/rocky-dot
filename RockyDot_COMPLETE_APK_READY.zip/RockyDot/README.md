# Rocky Dot — APK-ready Android AI Assistant

Rocky Dot is a Kotlin + Jetpack Compose Android app with:
- Voice input using Android SpeechRecognizer
- AI text replies through a secure backend
- Voice output using Android TextToSpeech
- Dark Dot-style UI
- No OpenAI API key embedded in the APK

## Architecture

Android APK -> HTTPS backend `/chat` -> OpenAI Responses API

The API key stays on the backend.

## 1. Build the Android app

Open the `android/` project in Android Studio, sync Gradle, then:
- Build > Build APK(s)

Or on a machine with Android SDK/Gradle wrapper configured:
```bash
./gradlew assembleDebug
```

The generated APK will be under:
`app/build/outputs/apk/debug/`

## 2. Deploy the backend

From `backend/`:
```bash
npm install
```

Set the environment variable:
```bash
OPENAI_API_KEY=your_key
```

Then:
```bash
npm start
```

For a public deployment, use any Node.js HTTPS host and set the same environment variable there.

## 3. Connect the APK

Edit:
`app/src/main/java/com/rockydot/app/ApiClient.kt`

Change:
`https://YOUR-BACKEND.example.com/chat`

to your deployed HTTPS `/chat` endpoint.

Then rebuild the APK.

## Important security note

Never put an OpenAI API key directly inside the Android app. APKs can be inspected. Keep the key on the server as an environment variable.

## Current MVP

This first build intentionally keeps the core loop simple:
voice -> text -> backend AI -> text -> voice.

Next upgrades can add persistent chat history, wake-word behavior, reminders, web search, custom tools, and a richer Dot animation.

## Cloud build

The repository includes `.github/workflows/android.yml`. Push the project to GitHub,
then run the workflow from the Actions tab. It uploads `app-debug.apk` as an artifact.

## Backend cloud deployment

`backend/render.yaml` is included as a deployment template. Set `OPENAI_API_KEY`
as a secret/environment variable on the backend host. Never commit `.env`.

## Model

The backend defaults to `gpt-6-astra`, an OpenAI API model available through the
Responses API. You can change it with `OPENAI_MODEL`.

## Production checklist

- Use HTTPS for the backend URL.
- Add authentication/rate limiting before public release.
- Keep the OpenAI API key server-side.
- Replace the placeholder URL in `ApiClient.kt`.
- Build a release-signed APK/AAB for Play Store distribution.
